<?php

namespace idoit\Module\Api\Model\Cmdb\Category\Processor\Provider;

/**
 * SyncModifier
 *
 * @package    idoit\Module\Api\Model\Category
 * @author     Selcuk Kekec <skekec@i-doit.com>
 * @copyright  synetics GmbH
 * @license    http://www.i-doit.com/license
 */
interface SyncModifier
{

    /**
     * Modify sync data
     *
     * @param array $syncData
     *
     * @return array
     */
    public function modifySyncData(array $syncData);
}