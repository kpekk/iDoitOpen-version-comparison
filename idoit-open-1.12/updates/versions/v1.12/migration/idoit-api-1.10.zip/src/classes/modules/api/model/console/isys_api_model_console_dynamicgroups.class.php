<?php

/**
 * i-doit
 *
 * @package    i-doit
 * @subpackage API
 * @author     Selcuk Kekec <skekec@i-doit.de>
 * @version    1.10
 * @copyright  synetics GmbH
 * @license    http://www.i-doit.com/license
 */

use idoit\Console\Command\Idoit\DynamicGroupsSyncCommand;

/**
 * Class isys_api_model_console_dynamicgroups
 */
class isys_api_model_console_dynamicgroups extends isys_api_model_console
{
    /**
     * Clean authentication cache
     *
     * @param array $params
     *
     * @return array
     * @throws Exception
     */
    public function sync(array $params = [])
    {
        $this->commandExists(DynamicGroupsSyncCommand::class);

        return $this->run(DynamicGroupsSyncCommand::NAME, $params['options'], $params['arguments']);
    }
}