<?php

/**
 * i-doit
 *
 * @package    i-doit
 * @subpackage API
 * @author     Selcuk Kekec <skekec@i-doit.de>
 * @version    1.10
 * @copyright  synetics GmbH
 * @license    http://www.i-doit.com/license
 */

use idoit\Console\Command\Internal\GenerateAllSettingsCommand;

/**
 * Class isys_model_console_settings
 */
class isys_api_model_console_settings extends isys_api_model_console
{
    /**
     * Get all settings
     *
     * @param array $params
     *
     * @return array
     * @throws Exception
     */
    public function all(array $params = [])
    {
        /**
         * @todo Make this one work!
         */

        // Check whether command exists
        $this->commandExists(GenerateAllSettingsCommand::class);

        return $this->run(GenerateAllSettingsCommand::NAME, $params['options'], $params['arguments']);
    }
}