<?php

namespace idoit\Module\Api\Logging;

use idoit\Component\Provider\Singleton;
use Monolog\Logger;

/**
 * Class LineFormatter
 *
 * @package idoit\Module\Api
 */
class ApiLogger extends Logger
{
    use Singleton;
}
