<?php

/**
 * i-doit
 *
 * @package    i-doit
 * @subpackage API
 * @author     Selcuk Kekec <skekec@i-doit.de>
 * @version    1.10
 * @copyright  synetics GmbH
 * @license    http://www.i-doit.com/license
 */

use idoit\Module\Report\Console\Command\ReportExportCommand;

/**
 * Class isys_model_console_report
 */
class isys_api_model_console_report extends isys_api_model_console
{
    /**
     * Export report
     *
     * @param array $params
     *
     * @return array
     * @throws Exception
     */
    public function export(array $params = [])
    {
        // Check whether command exists
        $this->commandExists(ReportExportCommand::class);

        return $this->run(ReportExportCommand::NAME, $params['options'], $params['arguments']);
    }
}