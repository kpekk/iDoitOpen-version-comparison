<?php

namespace idoit\Module\Api\Model\Cmdb\Category\Processor;

/**
 * ConnectorProcessor
 *
 * @package    idoit\Module\Api\Model\Category
 * @author     Selcuk Kekec <skekec@i-doit.com>
 * @copyright  synetics GmbH
 * @license    http://www.i-doit.com/license
 */
class ConnectorProcessor extends PortProcessor
{
    /**
     * Get cable property name
     *
     * @return string
     */
    protected function getCablePropertyName()
    {
        return 'cable_connection';
    }
}