<?php

namespace idoit\Module\Api\Model\Cmdb\Category\Processor\Provider;

/**
 * ResponseModifier
 *
 * @package    idoit\Module\Api\Model\Category
 * @author     Selcuk Kekec <skekec@i-doit.com>
 * @copyright  synetics GmbH
 * @license    http://www.i-doit.com/license
 */
interface ResponseModifier
{
    /**
     * Modify api response
     *
     * @param array $response
     *
     * @return array
     */
    public function modifyResponse(array $response);
}