<?php

namespace idoit\Module\Api\Model\Cmdb\Category\Processor\Provider;

/**
 * RequestModifier
 *
 * @package    idoit\Module\Api\Model\Category
 * @author     Selcuk Kekec <skekec@i-doit.com>
 * @copyright  synetics GmbH
 * @license    http://www.i-doit.com/license
 */
interface RequestModifier
{
    /**
     * Modify api request
     *
     * @param array $request
     *
     * @return array
     */
    public function modifyRequest(array $request);
}