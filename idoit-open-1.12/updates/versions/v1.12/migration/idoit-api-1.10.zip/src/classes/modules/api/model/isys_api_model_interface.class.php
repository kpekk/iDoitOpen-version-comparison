<?php

/**
 * i-doit
 *
 * API model interface
 *
 * @package    i-doit
 * @subpackage API
 * @author     Dennis Stücken <dstuecken@synetics.de>
 * @copyright  synetics GmbH
 * @license    http://www.i-doit.com/license
 */
interface isys_api_model_interface
{
    /**
     * Read data.
     *
     * @param string $p_method Data method
     * @param array  $p_params Parameters (depends on data method)
     *
     * @return mixed
     */
    public function read($p_params);
}